from functions import func
print(func(0,0))
